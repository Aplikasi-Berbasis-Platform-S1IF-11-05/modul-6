let dataTable;
let currentDeleteId = null;

// Load DataTable
function loadProducts() {
    $.ajax({
        url: '/api/products',
        method: 'GET',
        success: function(products) {
            if (dataTable) {
                dataTable.clear().destroy();
            }
            const tbody = $('#productsTable tbody');
            tbody.empty();
            products.forEach(prod => {
                const row = `<tr>
                    <td>${prod.id}</td>
                    <td>${escapeHtml(prod.name)}</td>
                    <td>${formatRupiah(prod.price)}</td>
                    <td>${prod.stock}</td>
                    <td>${escapeHtml(prod.description || '-')}</td>
                    <td>
                        <button class="btn btn-sm btn-warning edit-btn" data-id="${prod.id}"><i class="bi-pencil"></i> Edit</button>
                        <button class="btn btn-sm btn-danger delete-btn" data-id="${prod.id}" data-name="${escapeHtml(prod.name)}"><i class="bi-trash"></i> Hapus</button>
                    </td>
                </tr>`;
                tbody.append(row);
            });
            dataTable = $('#productsTable').DataTable({
                pageLength: 10,
                language: { url: '//cdn.datatables.net/plug-ins/1.13.6/i18n/id.json' }
            });
        },
        error: () => alert('Gagal memuat data produk')
    });
}

function openCreateModal() {
    $('#modalTitle').text('Tambah Produk');
    $('#productId').val('');
    $('#productForm')[0].reset();
    $('#productModal').modal('show');
}

function openEditModal(id) {
    $.ajax({
        url: `/api/products/${id}`,
        method: 'GET',
        success: (product) => {
            $('#modalTitle').text('Edit Produk');
            $('#productId').val(product.id);
            $('#name').val(product.name);
            $('#price').val(product.price);
            $('#stock').val(product.stock);
            $('#description').val(product.description);
            $('#productModal').modal('show');
        },
        error: () => alert('Data tidak ditemukan')
    });
}

$('#saveBtn').on('click', () => {
    const id = $('#productId').val();
    const productData = {
        name: $('#name').val(),
        price: $('#price').val(),
        stock: $('#stock').val(),
        description: $('#description').val()
    };
    const method = id ? 'PUT' : 'POST';
    const url = id ? `/api/products/${id}` : '/api/products';
    $.ajax({
        url: url,
        method: method,
        contentType: 'application/json',
        data: JSON.stringify(productData),
        success: () => {
            $('#productModal').modal('hide');
            loadProducts();
        },
        error: (err) => alert('Error: ' + (err.responseJSON?.message || 'Gagal simpan'))
    });
});

$(document).on('click', '.edit-btn', function() {
    const id = $(this).data('id');
    openEditModal(id);
});

$(document).on('click', '.delete-btn', function() {
    currentDeleteId = $(this).data('id');
    const name = $(this).data('name');
    $('#deleteProductName').text(name);
    $('#deleteModal').modal('show');
});

$('#confirmDeleteBtn').on('click', () => {
    if (currentDeleteId) {
        $.ajax({
            url: `/api/products/${currentDeleteId}`,
            method: 'DELETE',
            success: () => {
                $('#deleteModal').modal('hide');
                loadProducts();
            },
            error: () => alert('Gagal menghapus produk')
        });
    }
});

function formatRupiah(angka) {
    return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(angka);
}

function escapeHtml(str) {
    if(!str) return '';
    return str.replace(/[&<>]/g, function(m) {
        if (m === '&') return '&amp;';
        if (m === '<') return '&lt;';
        if (m === '>') return '&gt;';
        return m;
    });
}

$(document).ready(() => {
    loadProducts();
});